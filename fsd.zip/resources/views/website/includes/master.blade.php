@include('website.includes.header')
@yield('content')
@include('website.includes.footer')
@include('website.includes.errors')
