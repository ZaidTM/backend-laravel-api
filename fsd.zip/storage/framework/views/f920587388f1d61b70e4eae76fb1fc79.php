<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger" role="alert">
            <i data-feather="alert-circle"></i>
            <?php echo e($error); ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php if(Session::has('message')): ?>
    <div class="alert alert-success" role="alert">
        <i data-feather="alert-circle"></i>
        <?php echo e(Session::get('message')); ?>

    </div>
<?php endif; ?>
<?php if(Session::has('error')): ?>
    <div class="alert alert-danger" role="alert">
        <i data-feather="alert-circle"></i>
        <?php echo e(Session::get('error')); ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\softrobo\fsd\resources\views/website/includes/errors.blade.php ENDPATH**/ ?>