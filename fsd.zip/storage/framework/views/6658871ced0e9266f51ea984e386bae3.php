<?php $__env->startSection('title'); ?>
    BBC News
<?php $__env->stopSection(); ?>

<style>
    .card {
        margin-bottom: 20px;
    }

    .card-title {
        font-size: 1.5rem;
        margin-bottom: 10px;
    }

    .card-text {
        margin-bottom: 10px;
    }

    .list-group {
        margin-top: 20px;
    }

</style>

<?php $__env->startSection('content'); ?>

    <main id="main">

        <!-- ======= Breadcrumbs ======= -->
        <section id="breadcrumbs" class="breadcrumbs">
            <div class="container">

                <ol>
                    <li><a href="<?php echo e(route('/')); ?>">Home</a></li>
                    <li>Guardiann News</li>
                </ol>

            </div>
        </section><!-- End Breadcrumbs -->

        <section class="inner-page">
            <div class="container">

                <form action="<?php echo e(route('bbcnews')); ?>" id="NewFilterForm" method="get">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-xl-12"><?php echo $__env->make('website.includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                        <div class="col-lg-4 mt-4 mt-md-0">
                            <label for="">Heading</label>
                            <input type="text" class="form-control" name="filter" id="filter"
                                   placeholder="Filter News"
                                   value="<?php echo e(($request->filter) ? $request->filter : ''); ?>">
                        </div>
                        <div class="col-lg-2 mt-4 mt-md-0">
                            <label for="">Date</label>
                            <input type="date" name="date" class="form-control" placeholder="Date"
                                   value="<?php echo e(($request->date) ? $request->date : ''); ?>">
                        </div>
                        <div class="col-lg-2 mt-4 mt-md-0">
                            <label for="">Source</label>
                            <input type="text" name="source" class="form-control" placeholder="Source"
                                   value="<?php echo e(($request->source) ? $request->source : ''); ?>">
                            <input type="hidden" name="page" id="page"
                                   value="<?php echo e(($request->page) ? $request->page : 1); ?>">
                        </div>
                        <div class="col-lg-2 mt-4 mt-md-0">
                            <label for="">Sort By</label>
                            <select name="sortBy" class="form-control">
                                <option
                                    <?php echo e(($request->sortBy && $request->sortBy=="relevance") ? 'selected' : ''); ?> value="relevance">
                                    Relevance
                                </option>
                                <option
                                    <?php echo e(($request->sortBy && $request->sortBy=="newest") ? 'selected' : ''); ?> value="newest">
                                    Newest
                                </option>
                                <option
                                    <?php echo e(($request->sortBy && $request->sortBy=="oldest") ? 'oldest' : ''); ?> value="oldest">
                                    Oldest
                                </option>
                            </select>
                        </div>
                        <div class="col-lg-2 mt-4 mt-md-0">
                            <button type="submit" class="btn btn-primary p-3 mt-4">Filter News</button>
                            <a href="<?php echo e(route('bbcnews')); ?>" type="submit" class="btn btn-danger p-3 mt-4">Reset</a>
                        </div>
                    </div>
                </form>


                <div class="row mt-5">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">

                                <?php if($all_articles): ?>
                                    <?php
                                        $totalpage =  $all_articles->pages;
                                    ?>
                                    <div class="row my-3">
                                        <div class="col-md-4"><h4 style="margin-top:13px"><b>Search Results
                                                    (<?php echo e($all_articles->total); ?>)</b></h4></div>
                                        <div class="col-md-4"><input type="text" onkeyup="myFunction()" id="FIlterNews"
                                                                     class="form-control"
                                                                     placeholder="Search By Heading . . . "></div>
                                        <div class="col-md-4" style="text-align: right !important;">

                                            <?php if($request->page==1): ?>
                                                <button disabled class="btn btn-dark p-3 text-white">Back</button>
                                            <?php else: ?>
                                                <button onclick="PreviousPage()" class="btn btn-dark p-3 text-white">
                                                    Back
                                                </button>
                                            <?php endif; ?>

                                            <?php if($request->page < $totalpage+1): ?>
                                                <button onclick="NextPage()" class="btn btn-dark p-3 text-white">Next
                                                </button>
                                            <?php else: ?>
                                                <button disabled class="btn btn-dark p-3 text-white">Next
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <?php $__empty_1 = true; $__currentLoopData = $all_articles->results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="card cardsearch">
                                            <div class="card-body">
                                                <h5 class="card-title">
                                                    <a href="<?php echo e(($all_article->webUrl) ? $all_article->webUrl : ''); ?>"
                                                       target="_blank" class="text-dark"><b class="News_Heading"><?php echo e(($all_article->webTitle) ? $all_article->webTitle : ''); ?></b>
                                                    </a>
                                                </h5>
                                                <p>
                                                    <b><?php echo e(\Carbon\Carbon::parse($all_article->webPublicationDate)->diffForhumans()); ?></b>
                                                </p>
                                                
                                                <h6><b>Tags : </b></h6>
                                                <?php $__empty_2 = true; $__currentLoopData = $all_article->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                    <a href="<?php echo e(($tag->webUrl) ? $tag->webUrl : ''); ?>"
                                                       target="_blank" class="btn btn-primary mb-2"><?php echo e(($tag->webTitle) ? $tag->webTitle : ''); ?></a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <h4><b>Please Search Something . . . </b></h4>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                </div>


            </div>
        </section>

    </main><!-- End #main -->

<?php $__env->stopSection(); ?>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"
        integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>
<script>
    function myFunction() {
        var input, filter, cards, cardContainer, title, i;
        input = document.getElementById("FIlterNews");
        filter = input.value.toUpperCase();
        cards = document.getElementsByClassName("cardsearch");
        for (i = 0; i < cards.length; i++) {
            title = cards[i].querySelector(".News_Heading");
            if (title.innerText.toUpperCase().indexOf(filter) > -1) {
                cards[i].style.display = "";
            } else {
                cards[i].style.display = "none";
            }
        }
    }

    function NextPage() {
        var currentpage = $("#page").val();
        var nextpage = parseInt(currentpage) + 1;
        $("#page").val(nextpage);
        $("#NewFilterForm").submit();
    }

    function PreviousPage() {
        var currentpage = $("#page").val();
        if (parseInt(currentpage) > 1) {
            var previouspage = parseInt(currentpage) - 1;
            $("#page").val(previouspage);
            $("#NewFilterForm").submit();
        } else {
            var previouspage = 1;
            $("#page").val(previouspage);
            $("#NewFilterForm").submit();
        }
    }

</script>

<?php echo $__env->make('website.includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\softrobo\fsd\resources\views/website/users/bbcnews.blade.php ENDPATH**/ ?>